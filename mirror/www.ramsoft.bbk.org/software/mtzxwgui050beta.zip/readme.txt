MakeTZX WinGUI 0.50 BETA
------------------------

***********************************************************
This release of WinGUI DOESN'T WORK with MakeTZX for MSDOS!
You MUST download the Windows version of MakeTZX!
***********************************************************

For the documentation about this program, please see section "WinGUI" into
MakeTZX's manual (MTZXMAN.HTM) which is included into MakeTZX's package.
Get the latest version of MakeTZX from the Ramsoft homepage at:
http://www.ramsoft.bbk.org

Note that you must download MakeTZX for Windows too in order to use this program,
otherwise it's pretty useless, isn't it? :-)

(C)1999-2001 Ramsoft ZX Spectrum demogroup <ramsoft@bbk.org>
